<?php
require_once "controller/ControllerUsuario.php";

$object = new UsuarioController();

$object->Cadastrar();