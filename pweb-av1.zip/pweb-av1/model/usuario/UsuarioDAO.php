<?php 

  require_once "model/database/conn.php";

  class UsuarioDAO {
    private $connection;

    function __construct() {
      $db = new db();
      $this->connection = $db->getConnection();
    }

    function insert($user) {
      $query = "insert into usuarios (username,email,password) values (:username, :email, :password);";

      $stmt = $this->connection->prepare($query);

      $stmt->bindValue(":username", $user->getUsername());
      $stmt->bindValue(":email", $user->getEmail());
      $stmt->bindValue(":password", $user->getPassword());

      return $stmt->execute();
    }



    function select($user) {
      $query = "Select *From usuarios where password = :password;";
      $stmt = $this->connection->prepare($query);
      $stmt->bindValue(":password", $user->getPassword());

      $stmt->execute();
  
      $users = $stmt->fetchAll();
  
      return $users;
    }
  }