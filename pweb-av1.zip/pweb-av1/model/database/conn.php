<?php
  class db {
    private $username = "root";
    private $password = "";
    private $database = "pweb";
    private $connection;

    function __construct() {
      $this->connection = new PDO("mysql:host=localhost;dbname=$this->database", $this->username, $this->password);
    }

    function getConnection() {
      return $this->connection;
    }
  }