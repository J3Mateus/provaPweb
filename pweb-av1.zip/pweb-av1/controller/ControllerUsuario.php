<?php 

  require_once "model/usuario/Usuario.php";
  require_once "model/usuario/UsuarioDAO.php";

  class UsuarioController {
    private $UsuarioDAO;

    function __construct() {
      $this->UsuarioDAO = new UsuarioDAO();
    }

    function Cadastrar() {
      $Usuario = new Usuario(
        0,
        $_POST["username"],
        $_POST["email"],
        $_POST["password"]
      );

      if ($this->UsuarioDAO->insert($Usuario)) {
        echo "Usuário cadastrado!</p>";
      } else {
        echo "erro !</p>";
      }
    }

    function Buscar() {
      $Usuario = new Usuario(
        0,
        $_POST["username"],
        "Email",
        $_POST["password"]
      );

      $users = $this->UsuarioDAO->select($Usuario);

      if (isset($users)) {
        print_r("Dados abaixo do usuario");
        foreach($users as $user) {
          print_r("ID: ". $user[0]."</br>");
          print_r("Nome: ". $user[1]."</br>");
          print_r("Email: ". $user[2]."</br><br/>");
        }
      }else {
        print_r("Usuario não autenticado>");
      }
    }

}