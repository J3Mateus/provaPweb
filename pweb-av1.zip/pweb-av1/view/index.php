<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prova PWEB</title>
</head>
<body>
    <form action="http://localhost/pweb-av1/req.php" method="post">
    <label for="username">
      Nome:
      <input type="text" id="username" name="username"/>
    </label>

    <label for="email">
      E-mail:
      <input type="text" id="email" name="email"/>
    </label>

    <label for="password">
      Senha:
      <input type="password" id="password" name="password"/>
    </label>

    <input type="submit" value="Cadastrar" />
  </form>
        <div>Autenticar</div>
  <form action="http://localhost/pweb-av1/req2.php" method="post">
    <label for="username">
      Nome:
      <input type="text" id="username" name="username"/>
    </label>
    
    <label for="password">
      Senha:
      <input type="password" id="password" name="password"/>
    </label>

    <input type="submit" value="Cadastrar" />
  </form>





</body>
</html>